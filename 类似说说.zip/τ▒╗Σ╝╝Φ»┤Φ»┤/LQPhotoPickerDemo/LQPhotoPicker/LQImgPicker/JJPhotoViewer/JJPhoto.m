//
//  JJPhoto.m
//  test
//
//  Created by KimBox on 15/4/28.
//  Copyright (c) 2015年 KimBox. All rights reserved.
//

#import "JJPhoto.h"

@implementation JJPhoto

@end
