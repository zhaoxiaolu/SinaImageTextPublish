#LQ系列-UI模块:
####LQPhotoPickerDemo - https://github.com/XZTLLQ/LQPhotoPickerDemo
####LQIMInputView - https://github.com/xztl/LQIMInputView
# LQPhotoPickerDemo
一个功能强大的图片选择器（类似QQ图片选择器），支持即时拍照存储立即选择，本地相册图片选择，图片个数自定义上限，图片选择记忆选择的图片，十分完美，还支持点击查看放大图片，获取图片的data数据时，对原图片进行保真压缩，大小为1M以内，方便大多数项目可以直接使用，提供源码欢迎大家提出问题和一起优化，该工具是根据一些开源项目的优秀代码筛选和自己的处理，做的一套能够满足绝大部分需求的选择图片并上传服务器的工具，该项目是对工具的使用demohttp://blog.csdn.net/jp940110jpjp/article/details/50012677
![](https://raw.githubusercontent.com/XZTLLQ/LQPhotoPickerDemo/master/REDMEIMG/IMG_0683.PNG)
![](https://raw.githubusercontent.com/XZTLLQ/LQPhotoPickerDemo/master/REDMEIMG/IMG_0684.PNG)
![](https://raw.githubusercontent.com/XZTLLQ/LQPhotoPickerDemo/master/REDMEIMG/IMG_0685.PNG)
![](https://raw.githubusercontent.com/XZTLLQ/LQPhotoPickerDemo/master/REDMEIMG/IMG_0711.PNG)
![](https://raw.githubusercontent.com/XZTLLQ/LQPhotoPickerDemo/master/REDMEIMG/IMG_0712.PNG)
![](https://raw.githubusercontent.com/XZTLLQ/LQPhotoPickerDemo/master/REDMEIMG/IMG_0713.PNG)
![](https://raw.githubusercontent.com/XZTLLQ/LQPhotoPickerDemo/master/REDMEIMG/IMG_0714.PNG)
